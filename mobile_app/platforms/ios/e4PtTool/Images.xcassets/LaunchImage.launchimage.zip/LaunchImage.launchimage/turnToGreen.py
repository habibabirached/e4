import os
from PIL import Image

def remove_red_component(directory='.'):
    # Loop through all files in the specified directory
    for filename in os.listdir(directory):
        # Check if the file is a PNG image
        if filename.endswith('.png'):
            # Open the image
            image_path = os.path.join(directory, filename)
            with Image.open(image_path) as img:
                # Ensure the image is in RGB mode
                img = img.convert("RGB")
                # Load image data into a pixel array
                pixels = img.load()

                # Modify each pixel to set the red component to 11
                for x in range(img.width):
                    for y in range(img.height):
                        r, g, b = pixels[x, y]
                        pixels[x, y] = (11, g, b)  # Set red component to 11

                # Save the modified image, overwriting the original
                img.save(image_path)

if __name__ == '__main__':
    remove_red_component()
